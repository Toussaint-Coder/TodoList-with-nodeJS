/** @format */
import Marathon from "../assets/premium_photo-1663090417989-b399378d45ac.avif";

export const Popular = () => (
  <div className="max-w-[1400px] mx-auto">
    <div className="mb-6">
      <h1 className="font-bold text-5xl font-onest">Latest News</h1>
    </div>
    <div className="flex gap-8">
      {[1, 2, 3, 4].map((index) => (
        <div className="flex-1" key={index}>
          <div>
            <div className=" overflow-hidden ">
              <img
                src={Marathon}
                alt="swimming"
                className="object-cover rounded-lg h-full"
              />
            </div>
            <div className="py-2">
              <h1 className="font-bold text-2xl">
                National Swimming Championship
              </h1>
            </div>
            <div>
              <p className="text-secondary text-base">Swimming | 2 Years ago</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);
