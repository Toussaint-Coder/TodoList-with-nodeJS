/** @format */
import Swimming from "../assets/maksym-tymchyk-bGOBoZorNoQ-unsplash.jpg";
import Marathon from "../assets/premium_photo-1663090417989-b399378d45ac.avif";
import Victoria from "../assets/victoria-prymak-CCe_Xt5sEDA-unsplash.jpg";
export default function Latest() {
  return (
    <div className="max-w-[1400px] mx-auto">
      <div>
        <h1 className="font-bold text-5xl font-onest">Latest News</h1>
      </div>
      <div className="flex mt-6 gap-8">
        <div className="flex gap-4 max-w-[695px] flex-1">
          <div className="flex-1 flex gap-4">
            <div className="flex-1 max-w-[339px]">
              <div>
                <div className="h-[209px] overflow-hidden ">
                  <img
                    src={Swimming}
                    alt="swimming"
                    className="object-cover rounded-lg h-full"
                  />
                </div>
                <div className="py-2">
                  <h1 className="font-bold text-2xl">
                    National Swimming Championship
                  </h1>
                </div>
                <div>
                  <p className="text-secondary text-base">
                    Swimming | 2 Years ago
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-1 flex gap-4 ">
            <div className="flex-1 max-w-[339px]">
              <div>
                <div className="h-[209px] overflow-hidden ">
                  <img
                    src={Marathon}
                    alt="swimming"
                    className="object-cover rounded-lg h-full"
                  />
                </div>
                <div className="py-2">
                  <h1 className="font-bold text-2xl">
                    Kenya Dominates Boston Marathon 2024
                  </h1>
                </div>
                <div>
                  <p className="text-secondary text-base">
                    Swimming | 2 Years ago
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex-1">
          <div className="flex flex-col gap-4">
            {[1,2,3].map((index) => (
              <div className="flex items-center gap-2" key={index}>
                <div className="w-[139px] h-[112px] bg-black rounded-lg overflow-hidden">
                  <img
                    src={Victoria}
                    alt="photo"
                    className="object-cover h-full"
                  />
                </div>
                <div className="max-w-[292px]">
                  <p className="text-2xl font-onest font-bold">
                    Arsenal Tops Premier League Table After Dra...
                  </p>
                  <p className="text-secondary text-base">
                    Swimming | 2 Years ago
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
