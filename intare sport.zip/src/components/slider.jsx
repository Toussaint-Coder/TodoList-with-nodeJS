/** @format */
import { Splide, SplideSlide } from "@splidejs/react-splide";
import "@splidejs/react-splide/css";
import Swimming from "../assets/maksym-tymchyk-bGOBoZorNoQ-unsplash.jpg";

export default function Slide({}) {
  const data = [
    {
      image: Swimming,
      title: "National Swimming Championship",
      location: "Olympic Aquatic Center, Bujumbura, Burundi",
      description:
        "The annual National Swimming Championship features top swimmers competing across freestyle, backstroke, breaststroke, and butterfly events. Open for all ages and categories.",
    },

    {
      image: Swimming,
      title: "International Tennis Tournament",
      location: "Tennis Stadium, Kigali, Rwanda",
      description:
        "The International Tennis Tournament brings together top tennis players from around the world to compete in singles and doubles events.",
    },

    {
      image: Swimming,
      title: "Regional Athletics Meet",
      location: "National Stadium, Dar es Salaam, Tanzania",
      description:
        "The Regional Athletics Meet features athletes competing in track and field events, including sprints, distance running, and jumping events.",
    },
  ];
  return (
    <section className="h-2/3 relative">
      <Splide
        options={{
          type: "loop",
          autoplay: true,
          interval: 5000,
          perPage: 1,
          arrows: false,
          pagination: true,
        }}>
        {data.map((item, index) => (
          <SplideSlide key={index}>
            <div
              className="min-h-[595px] bg-cover bg-center bg-no-repeat flex justify-center gap-4 flex-col px-[56px] bg-yellow-200 relative max-w-[1400px] mx-auto rounded-lg"
              style={{
                backgroundImage: `linear-gradient(to top, rgba(0, 0, 0, 0.24), rgba(0, 0, 0, 0.24)),url(${item.image})`,
              }}>
              <div className="flex gap-2 items-center">
                <svg
                  width="18"
                  height="24"
                  viewBox="0 0 18 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M9 0C4.02975 0 0 4.02975 0 9C0 10.9571 0.641625 12.753 1.70813 14.2238C1.72725 14.259 1.73025 14.2984 1.752 14.3321L7.752 23.3321C8.03025 23.7495 8.499 24 9 24C9.501 24 9.96975 23.7495 10.248 23.3321L16.248 14.3321C16.2701 14.2984 16.2727 14.259 16.2919 14.2238C17.3584 12.753 18 10.9571 18 9C18 4.02975 13.9703 0 9 0ZM9 12C7.34325 12 6 10.6567 6 9C6 7.34325 7.34325 6 9 6C10.6567 6 12 7.34325 12 9C12 10.6567 10.6567 12 9 12Z"
                    fill="white"
                  />
                </svg>
                <span className="text-white font-nunito text-sm">
                  {item.location}
                </span>
              </div>
              <div className="max-w-[795px]">
                <div className="max-w-[457px]">
                  <h1 className="text-5xl font-bold text-white font-onest leading-[55px]">
                    {item.title}
                  </h1>
                </div>
                <div className="mt-4">
                  <p className="text-white text-xl">{item.description}</p>
                </div>
                <div className="mt-4">
                  <button className="bg-white text-black py-2 px-4 rounded">
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          </SplideSlide>
        ))}
      </Splide>
    </section>
  );
}
