/** @format */
import Photo from "../assets/victoria-prymak-CCe_Xt5sEDA-unsplash.jpg";
export const Advertising = () => (
  <div className="max-w-[1400px] flex mx-auto bg-secondary min-h-[414px] mt-6 rounded-lg">
    <div className="flex-1 flex justify-center items-start flex-col px-10 gap-4">
      <div className="text-4xl font-bold font-onest">
        <h1>Sign up for our newsletter</h1>
      </div>
      <div>
        <p className="text-base">
          No spam ever, we care about the protection of <br /> your data.
        </p>
      </div>
      <div>
        <input type="text" className="w-96 p-3 bg-white/70 border rounded-lg border-black"/>
      </div>
      <button className="px-8 py-3 rounded-lg bg-black text-white">Subscribe</button>
    </div>
    <div className="flex-1" style={{ background: `url(${Photo})` }}>
      {/* Ads */}
    </div>
  </div>
);
