/** @format */
import logo from "../assets/logo.svg";
import moon from "../assets/moon.svg"
import profile from "../assets/profile.svg"
export default function Menu() {
  return (
    <div classname="w-full sticky top-0">
      <div className="w-full border-b mb-8 bg-white flex items-center justify-between px-14">
        <div className="py-7 ">
          <img src={logo} alt="logo" />
        </div>
        <div>
          <ul className="flex items-center gap-4 font-nunito">
            <li className="hover:text-secondary cursor-pointer">Home</li>
            <li className="hover:text-secondary cursor-pointer">News</li>
            <li className="hover:text-secondary cursor-pointer">Videos</li>
            <li className="hover:text-secondary cursor-pointer">Teams</li>
            <li className="hover:text-secondary cursor-pointer">Tournamants</li>
            <li className="hover:text-secondary cursor-pointer">Continents</li>
          </ul>
        </div>
        <div>
            <input type="text" className="min-w-[302px] text-sm rounded-md bg-black/10 w-full px-2 py-2 focus:outline-1 focus:outline-secondary" placeholder="Search News" />
        </div>
        <div className="flex items-center gap-2">
            <img src={moon} alt="moon"/>
            <img src={profile} alt="profile"/>
        </div>
      </div>
    </div>
  );
}
