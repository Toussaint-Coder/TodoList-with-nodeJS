/** @format */

import { createContext } from "react";
import Swimming from "../assets/maksym-tymchyk-bGOBoZorNoQ-unsplash.jpg";

export const SportDataContext = createContext();
const data = [
  {
    image: Swimming,
    title: "National Swimming Championship",
    location: "Olympic Aquatic Center, Bujumbura, Burundi",
    description:
      "The annual National Swimming Championship features top swimmers competing across freestyle, backstroke, breaststroke, and butterfly events. Open for all ages and categories.",
  },

  {
    image: Swimming,
    title: "International Tennis Tournament",
    location: "Tennis Stadium, Kigali, Rwanda",
    description:
      "The International Tennis Tournament brings together top tennis players from around the world to compete in singles and doubles events.",
  },

  {
    image: Swimming,
    title: "Regional Athletics Meet",
    location: "National Stadium, Dar es Salaam, Tanzania",
    description:
      "The Regional Athletics Meet features athletes competing in track and field events, including sprints, distance running, and jumping events.",
  },
];
export const SportDataProvider = ({ children }) => (
  <SportDataContext.Provider value={data}>{children}</SportDataContext.Provider>
);
