/** @format */
import React from "react";
import Menu from "../components/Menu";
import Slide from "../components/slider";
import Latest from "../components/Latest";
import { Popular } from "../components/Popular";
import { Advertising } from "../components/Advertising";
const Home = () => {
  return (
    <div className="w-full h-screen">
      <Menu />
      <Slide />
      <Latest />
      <Popular />
      <Advertising/>
    </div>
  );
};

export default Home;
