/** @format */
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Home from "./pages/home";
import {
  SportDataContext,
  SportDataProvider,
} from "./context/SportDataContext";

function App() {
  return (
    <>
      <SportDataProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
          </Routes>
        </BrowserRouter>
      </SportDataProvider>
    </>
  );
}

export default App;
